

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.Random;

/**
 * Servlet implementation class otp
 */
@WebServlet("/otp")
public class otp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public otp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession HS = request.getSession();
		
		String email = (String) HS.getAttribute("email");
		int otp = (int) (Math.random() * ((9999 - 1000 ) + 1) + 1000);
		String host="smtp.gmail.com";  
		String FromEmailID="snapdragon7gamer@gmail.com";//change accordingly  
		String password="orsblsrtnoutelly";//change accordingly  
		String port = "587";
		String to = email ;//change accordingly  
		String Subject = "OTP";
		String Body = "OTP = " + otp;
		HS.setAttribute("otp", otp);
		
				
		//Get the session object  
		Properties props = new Properties();  
		props.setProperty("mail.smtp.host",host);  
		props.setProperty("mail.smtp.port", port);
		props.setProperty("mail.smtp.user", FromEmailID);
		props.setProperty("mail.smtp.auth", "true");  
		props.setProperty("mail.smtp.starttls.enable", "true");
		
	    try {
	    	Session oSession; 
			oSession = Session.getInstance(props,new javax.mail.Authenticator() {  
			     protected PasswordAuthentication getPasswordAuthentication() {  
						  return new PasswordAuthentication(FromEmailID,password);  
			     }  
			   });  
		    
	    	MimeMessage message = new MimeMessage(oSession);  
	    	message.setFrom(new InternetAddress(FromEmailID));  
	    	message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	    	message.setSubject(Subject);  
	    	message.setText(Body);
	       
	    	//send the message  
	    	Transport.send(message);  
	    	response.sendRedirect("otpcheck.jsp");
	  
	    	System.out.println("message sent successfully...");  
	    } catch (MessagingException e) {
	    	 System.out.println(e.toString());
	    	 PrintWriter out = response.getWriter();
	    	 out.println("Failed to Send OTP");
	    }  
}       


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
