import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

public class UploadServlet extends HttpServlet {
    
    private static final String UPLOAD_DIR = "media/";

	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the directory where the files will be uploaded
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
        
        // Create the directory if it doesn't exist
        File fileSaveDir = new File(uploadFilePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdirs();
        }
        
        // Process each uploaded file
        List<Part> fileParts = request.getParts().stream().filter(part -> "file".equals(part.getName())).collect(Collectors.toList());
        for (Part part : fileParts) {
            String fileName = Paths.get(part.getSubmittedFileName()).getFileName().toString();
            String filePath = uploadFilePath + File.separator + fileName;
            
            // Save the file to the upload directory
            InputStream fileContent = part.getInputStream();
            Files.copy(fileContent, Paths.get(filePath));
            
//            // Insert the file name into the database
            try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sap","root","root");) {
	            	Class.forName("com.mysql.cj.jdbc.Driver");
			PreparedStatement p = con.prepareStatement("insert into media(mname, mfolder, uid, selected) values(?,?,?,?)");
	    			p.setString(1, fileName);
	    			p.setString(2, request.getParameter("event"));
	    			p.setString(3, request.getParameter("client"));
	    			p.setString(4, "no");
	    			p.executeUpdate();
	    			response.sendRedirect("medias.jsp#data");
	    			response.Write("Images Uploaded.");
            } catch (SQLException ex) {
            	
            }
        }
        
        response.getWriter().println("Files uploaded successfully");
    }
}
