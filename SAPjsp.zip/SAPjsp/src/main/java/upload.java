

import java.io.File;
import java.io.IOException;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.sql.*;

/**
 * Servlet implementation class upload
 */
@WebServlet("/upload")
@MultipartConfig
public class upload extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public upload() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession ss = request.getSession();
		String uid = (String)ss.getAttribute("uid").toString();
		String savePath = "C:\\Users\\kalas\\eclipse-workspace\\SAPjsp\\src\\main\\webapp\\media\\" + request.getParameter("event")+"\\"; //specify your path here
		Part part=request.getPart("image");
		String fileName=part.getSubmittedFileName();
		part.write(savePath + fileName);
		response.setContentType("text/html");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sap","root","root");
			PreparedStatement p = con.prepareStatement("insert into media(mname, mfolder, uid, selected) values(?,?,?,?)");
			p.setString(1, fileName);
			p.setString(2, request.getParameter("event"));
			p.setString(3, request.getParameter("client"));
			p.setString(4, "no");
			p.executeUpdate();
			response.sendRedirect("medias.jsp#data");
			response.getWriter().println("Image " + fileName +"Uploaded to " + request.getParameter("event"));
		}
		catch(Exception ex) {
			response.getWriter().println(ex);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
